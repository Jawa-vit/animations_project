document.addEventListener("DOMContentLoaded", () => {
    document.addEventListener("mousemove", (e) => {
        const body = document.querySelector("body");
        const scratchern = document.createElement("span");

        scratchern.style.left = (e.clientX - 40) + "px";
        scratchern.style.top = (e.clientY - 40) + "px";
        body.append(scratchern);

        // Remove the span after 1 second
        setTimeout(() => {
            scratchern.remove();
        }, 5000);
    });
});
